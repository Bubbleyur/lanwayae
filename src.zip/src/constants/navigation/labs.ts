export const TOP_LEVEL_SECTIONS = [
  { name: "Get Started", href: "/labs/get-started" },
  {
    name: "Components",
    href: "/labs/components",
  },
  {
    name: "Changelog",
    href: "/labs/changelog",
  },
];
export const EXCLUDED_SECTIONS = ["installation"];
export const EXCLUDED_PAGES = ["/labs"];
