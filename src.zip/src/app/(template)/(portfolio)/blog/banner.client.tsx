"use client";
import Link from "next/link";
import dynamic from "next/dynamic";
import { PlusSeparator } from "@/components/ui/plus-separator";
import { useIsMobile } from "@/hooks/use-mobile";
import { useEffect, useState } from "react";

const GrainGradient = dynamic(
  () => import("@paper-design/shaders-react").then((mod) => mod.GrainGradient),
  {
    ssr: false,
  },
);

export function HeaderBanner() {
  const [showShaders, setShowShaders] = useState(false);
  useEffect(() => {
    // apply some delay, otherwise on slower devices, it errors with uniform images not being fully loaded.
    setTimeout(() => {
      setShowShaders(true);
    }, 400);
  }, []);

  const isMobile = useIsMobile();

  return (
    <section className="w-full border-separator/10 border-b">
      <div className="inner relative flex min-h-[250px] border-separator/10 border-x">
        <PlusSeparator
          position={["top-left", "top-right", "bottom-left", "bottom-right"]}
          main={{ className: "z-20" }}
        />
        {showShaders ? (
          <div className="h-[250px] w-full">
            <GrainGradient
              height={250}
              colors={["#c6750c", "#beae60", "#d7cbc6"]}
              colorBack="#ffffff00"
              softness={0.7}
              intensity={0.15}
              noise={isMobile ? 0.25 : 0.5}
              shape="wave"
              speed={0.7}
              scale={isMobile ? 1 : 2.5}
              offsetX={1}
              offsetY={0.6}
              className="w-full animate-fd-fade-in bg-background/20 duration-1000"
            />
          </div>
        ) : (
          <div className="h-[250px] w-full" />
        )}
        <div className="absolute top-0 right-0 bottom-0 left-0 z-10 h-full w-full text-white mix-blend-difference">
          <div className="mx-10 mt-12 flex h-full flex-col">
            <h2 className="text-2xl md:text-4xl">lanwayae's blog.</h2>
            <p className="text-sm md:text-base">
              here are some random thoughts I've written down.
            </p>
            <Link
              href="/blog/rss.xml"
              className="font-mono text-blue-600 hover:underline dark:text-blue-400"
            >
              [/rss.xml]
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
