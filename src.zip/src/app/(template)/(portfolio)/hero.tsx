"use client";
import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";

import moment from "moment-timezone";

import { cn } from "@/lib/utils";
import BauhausGenerator from "@/components/portfolio/bauhaus-generator";
import { PlusSeparator } from "@/components/ui/plus-separator";

import { cva } from "class-variance-authority";
import { useThemeStore } from "@/lib/store/hero-theme";

const backgroundImageVariants = cva("", {
  variants: {
    variant: {
      contour:
        "bg-[url(/static/images/hero-background/contour_dark.svg)] bg-no-repeat bg-cover bg-position-[center_top_30svh] dark:bg-[url(/static/images/hero-background/contour_light.svg)]",
      blackhole:
        "bg-[url(/static/images/hero-background/blackhole_dark.png)] bg-no-repeat bg-cover bg-position-[center_top_3svh] dark:bg-[url(/static/images/hero-background/blackhole_light.png)]",
    },
  },
  defaultVariants: {
    variant: "contour",
  },
});

export default function HeroSection() {
  const { themes, currentThemeIndex, cycleTheme } = useThemeStore();
  const currentTheme = themes[currentThemeIndex];

  return (
    <section className="relative flex flex-col">
      <div
        className={cn(
          "inner relative flex h-[80vh] flex-col justify-around border-separator/10 border-x border-t px-4 transition-all *:transition-all sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:gap-0 lg:px-16",
          backgroundImageVariants({ variant: currentTheme }),
        )}
      >
        <span className="flex flex-col *:transition-all">
          <div className="inline-block mb-4">
              <span className="font-mono text-xs text-sys-accent border border-sys-accent/30 bg-sys-accent/10 px-2 py-1">
                  v1.0.0 INITIALIZED
              </span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold leading-tight tracking-tight mb-6">
              ENGINEERING <br />
              <span className="text-sys-muted">DIGITAL SYSTEMS.</span>
          </h1>
          <p className="max-w-xl text-lg text-sys-muted font-light leading-relaxed">
              Curious junior developer focused on building real-world mobile and web applications, designing clean systems, working with databases, and exploring data scraping to solve practical problems through code.
          </p>
        </span>
        <span className="flex w-full justify-center md:w-auto md:justify-end">
          <p className="w-full max-w-[350px] text-center font-montreal-mono text-muted-foreground text-xs sm:text-sm md:text-base lg:w-auto lg:pt-52 lg:text-end">
            &quot;what began as curiosity slowly shaped how i think, build, and execute ideas.&quot;
          </p>
        </span>
      </div>
      <div className="border-separator/10 border-t">
        <div className="inner relative m-auto border-separator/10 border-x p-4">
          <span className="relative flex items-center justify-between font-montreal-mono text-xs opacity-90 transition-opacity duration-300 dark:opacity-75">
            <Link href="https://time.is/Surabaya" target="_blank">
              [<LocalTime />]
            </Link>
            <button type="button" onClick={cycleTheme}>
              <BauhausGenerator />
            </button>
          </span>
          <PlusSeparator position={["top-left", "top-right"]} />
        </div>
      </div>
    </section>
  );
}

const LocalTime = dynamic(
  () =>
    Promise.resolve(() => {
      const [localTime, setLocalTime] = useState<string>(
        moment.tz("Asia/Jakarta").format("h:mm A"),
      );

      useEffect(() => {
        const timeInterval = setInterval(() => {
          setLocalTime(moment.tz("Asia/Jakarta").format("h:mm A"));
        }, 5000);

        return () => clearInterval(timeInterval);
      }, []);

      return <>{localTime}</>;
    }),
  { ssr: false },
);
