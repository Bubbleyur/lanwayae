"use client";
import PageServerError from "./(partials)/error-pages/(template)/internal-server-error/page";
export default PageServerError;
